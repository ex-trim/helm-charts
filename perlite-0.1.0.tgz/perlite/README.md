# Siyuan Helm Chart

A Helm chart for Perlite, a web based markdown viewer optimized for Obsidian Notes. Just put your whole Obsidian vault or markdown folder/file structure in your web directory. The page builds itself.

Its an open source alternative to obsidian publish.

Read more about Perlite and staging tips on my blog post: Perlite on Secure77. If you want to discuss Perlite you can join the Perlite Discord Server

Source code can be found here:

- https://github.com/secure-77/Perlite

This is not an official helm chart

This chart deploys Perlite application with git-sidecar container for syncronization with your Obsidian-vault repository. You can use git-token or ssh-key for syncronization with private repository.

## Prerequisites

- Kubernetes 1.25+
- Helm 3+

## Installing the chart

```sh
helm repo add extrim https://ex-trim.github.io/helm-charts
helm install my-release extrim/perlite
```

## Uninstalling the chart

```sh
helm uninstall my-release
```

## Configuration

The following tables lists the configurable parameters of the Perlite chart and their default values.

| Parameter                  | Description                         | Default                                                 |
|----------------------------|-------------------------------------|---------------------------------------------------------|
| `image.repository`         | Image repository | `docker.io/extrim/perlite` |
| `image.tag`                | Image tag. Possible values listed [here](https://hub.docker.com/r/extrim/perlite/tags).| `latest`|
| `image.pullPolicy`         | Image pull policy | `IfNotPresent` |
| `imagePullSecrets`         | Image pull secrets | `[]` |
| `nameOverride`             | Name override | `""` |
| `fullnameOverride`         | Full name override | `""` |
| `ingress.enabled`          | Enables Ingress | `false` |
| `ingress.annotations`      | Ingress annotations | `{}` |
| `ingress.className`        | Ingress class name | `""` |
| `ingress.hosts`            | Ingress accepted hostnames | `chart-example.local` |
| `ingress.tls`              | Ingress TLS configuration | `[]` |
| `persistence.enabled`      | Use persistent volume to store configuration data | `false` |
| `persistence.size`         | Size of persistent volume claim | `500Mi` |
| `persistence.storageClass` | Type of persistent volume claim | `""` |
| `persistence.accessMode`   | Persistence access mode | `ReadWriteMany` |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`.

Read through the [values.yaml](values.yaml) file. It has several suggested values.

Also

- [Optional Perlite Settings](https://github.com/secure-77/Perlite/wiki/03---Perlite-Settings#optional-perlite-settings)
