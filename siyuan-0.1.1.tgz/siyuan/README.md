# Siyuan Helm Chart

A Helm chart for Siyuan, a privacy-first personal knowledge management system, support fine-grained block-level reference and Markdown WYSIWYG

Source code can be found here:

- https://github.com/siyuan-note/siyuan

This is not an official helm chart

## Prerequisites

- Kubernetes 1.25+
- Helm 3+

## Installing the chart

```sh
helm repo add extrim https://ex-trim.github.io/helm-charts
helm install my-release extrim/siyuan
```

## Uninstalling the chart

```sh
helm uninstall my-release
```

## Configuration

The following tables lists the configurable parameters of the Siyuan chart and their default values.

| Parameter                  | Description                         | Default                                                 |
|----------------------------|-------------------------------------|---------------------------------------------------------|
| `image.repository`         | Image repository | `docker.io/b3log/siyuan` |
| `image.tag`                | Image tag. Possible values listed [here](https://hub.docker.com/r/b3log/siyuan/tags/).| `latest`|
| `image.pullPolicy`         | Image pull policy | `IfNotPresent` |
| `imagePullSecrets`         | Image pull secrets | `[]` |
| `nameOverride`             | Name override | `""` |
| `fullnameOverride`         | Full name override | `""` |
| `timezone`                 | Timezone | `"UTC"` |
| `uid`                      | Container user id | `1000` |
| `gid`                      | Container group id | `1000` |
| `authCode`                 | Application auth code | _random generated on deploy if empty_ |
| `ingress.enabled`          | Enables Ingress | `false` |
| `ingress.annotations`      | Ingress annotations | `{}` |
| `ingress.labels`           | Custom labels | `{}` |
| `ingress.className`        | Ingress class name | `""` |
| `ingress.hosts`            | Ingress accepted hostnames | `chart-example.local` |
| `ingress.tls`              | Ingress TLS configuration | `[]` |
| `persistence.enabled`      | Use persistent volume to store configuration data | `false` |
| `persistence.size`         | Size of persistent volume claim | `500Mi` |
| `persistence.storageClass` | Type of persistent volume claim | `""` |
| `persistence.accessMode`   | Persistence access mode | `ReadWriteOnce` |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`.

Read through the [values.yaml](values.yaml) file. It has several suggested values.